# FSE / ESEC-FSE 精简模板

这是从 ACM 官方 `acmart` 模板精简出来的 FSE 论文模板，只保留编译所需的文件。

## 文件说明

| 文件 | 作用 |
|------|------|
| `main.tex` | 论文主文件，包含标题、摘要、正文结构、参考文献命令 |
| `references.bib` | 参考文献（BibTeX 格式），把真实引用替换进去 |
| `acmart.cls` | ACM 文档类（编译必需） |
| `ACM-Reference-Format.bst` | ACM 参考文献格式（编译必需） |
| `acm-jdslogo.png` | ACM 联合出版社 logo（编译必需） |
| `LICENSE` | ACM 模板许可证 |

## 在 Overleaf 中使用

1. 在 Overleaf 新建项目 → **Upload Project**，把本文件夹压缩成 zip 后上传，
   或者上传这 6 个文件到项目根目录。
2. 把编译器（Menu → Compiler）设为 **pdfLaTeX**。
3. Overleaf 会自动识别 `main.tex` 为入口文件（若没有，手动点开 `main.tex` 再编译）。

## 投稿 vs 定稿

`main.tex` 开头的 `\documentclass` 决定了格式：

- **审稿（双盲）**：`\documentclass[acmsmall,anonymous,review,screen]{acmart}`
  - `anonymous` 隐藏作者信息，`review` 显示行号，`screen` 彩色超链接
- **定稿（camera-ready）**：`\documentclass[acmsmall]{acmart}`

FSE 正文长度限制一般为 **10 页以内**（不含参考文献），以当年 CFP 为准。

## 需要你自己填写的内容

- 标题、作者、单位、邮箱
- 摘要、关键词
- CCS 分类（在 <https://dl.acm.org/ccs/ccs.cfm> 生成后替换）
- 正文各节内容
- `references.bib` 里的真实参考文献
- 定稿时补充 `\acmDOI`、`\acmISBN`、`\acmConference` 等版权信息

## 常用命令速查

- 引用文献：`\cite{example}`
- 图：`\begin{figure}...\includegraphics{fig.png}...\end{figure}`
- 表：`\begin{table}...\begin{tabular}{lcc}...\end{tabular}\end{table}`
- 公式：`\begin{equation}...\end{equation}`
- 列表：`\begin{itemize}\item ...\end{itemize}`
- 致谢：`\begin{acks}...\end{acks}`
