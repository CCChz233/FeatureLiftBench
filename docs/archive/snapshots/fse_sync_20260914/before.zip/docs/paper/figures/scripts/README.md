# 论文绘图源码

当前每张统计图有一个独立文件，文件内包含该图的完整绘图函数。原来集中在 `redraw_figures.py` 的布局代码已拆出；该文件现在只负责批量调用。

## 每张图改哪个文件

| 论文图 | 绘图源码 | 正式文件 | 状态 |
| --- | --- | --- | --- |
| Fig. 1：任务示意 | [legacy/fig1_motivation.py](legacy/fig1_motivation.py) | `../fig1.png` | 仅历史设计代码；当前 PNG 经 AI 编辑，无可精确重建的 Python 源码 |
| Fig. 2：构建与验证 | [legacy/fig2_construction.py](legacy/fig2_construction.py) | `../fig2.png` | 仅历史设计代码，保留旧 200 题文案；不生成当前定稿 |
| Fig. 3：任务组成 | [fig3_composition.py](fig3_composition.py) | `../fig3.pdf` | 当前定稿：降序堆叠图 + 4×4 热力图 |
| Fig. 4：功能结果 | [fig4_functional_results.py](fig4_functional_results.py) | `../fig4.pdf` | 当前定稿：首败阶段 + 通过频次 |
| Fig. 5：源码消融 | [fig5_source_ablation.py](fig5_source_ablation.py) | `../fig5.pdf` | 当前定稿：通过率 + 配对增益区间 |
| 附录 Fig. 6：产物差异 | [fig7_paired_footprint.py](fig7_paired_footprint.py) | `../fig7.pdf` | 当前定稿；源码和文件名保留历史编号 7，LaTeX 自动编号为 6 |

已移除的旧附录分类交叉图 `../fig6.pdf` 仅作历史产物保留，未找到独立旧 renderer；其中机制数据与当前绘制逻辑已集中到 `fig3_composition.py`。

## 单独画一张图

从项目根目录运行，例如只重画 Fig. 3：

```bash
python -B docs/paper/figures/scripts/fig3_composition.py
```

默认生成 `figures/output/fig3.pdf`、`figures/output/fig3.png`，并同步论文使用的 `figures/fig3.pdf`。数据核对和派生 JSON/索引仍由共享模块生成到 `figures/data/`。

如只想预览，不替换正式图片或派生数据：

```bash
python -B docs/paper/figures/scripts/fig3_composition.py --output-dir /tmp/flb-fig3-preview
```

输出目录中包含 PDF、PNG 及 `data/`。各脚本按自身位置解析数据路径，也可从其他工作目录用绝对路径执行。

## 批量入口

```bash
python -B scripts/paper.py figures
python -B docs/paper/figures/scripts/redraw_figures.py --only coverage ablation
python -B docs/paper/figures/scripts/redraw_figures.py --output-dir /tmp/flb-all-figures
```

`--only` 名称保持兼容：`coverage` → Fig. 3，`functional` → Fig. 4，`ablation` → Fig. 5，`footprint` → 附录产物差异图。

批量命令只运行四张当前统计图。Fig. 1/2 使用已有 PNG，不调用历史设计脚本。

## 共享模块

| 文件 | 职责 |
| --- | --- |
| [redraw_data.py](redraw_data.py) | 各图数据准备、任务范围、计数、配对与 bootstrap 核对 |
| [figure_data.py](figure_data.py) | 主结果读取、公共校验、Matplotlib 初始化及旧图数据函数 |
| [paper_style.py](paper_style.py) | 模型名称、统一字体、颜色、导出设置 |
| [figure_common.py](figure_common.py) | 公共颜色常量、单图命令行、PDF 同步与临时预览输出 |
| [redraw_figures.py](redraw_figures.py) | 批量调度；不再包含图形布局 |

源码依赖 Python、NumPy 和 Matplotlib，不需要运行 benchmark 或调用模型。修改单张图的布局、字号、注释请直接改对应 `fig*.py`；修改所有图的统一风格才改共享样式。

旧版、备选设计和历史编号见 [legacy/README.md](legacy/README.md)。
