# 论文图片

> **Status: current · Last verified: 2026-09-14**

这里只放 **当前压缩稿 `main.tex` 引用的七个文件**。清单以 [`paper_sources.json`](../paper_sources.json) 为准。

| 正文 | 文件 |
| --- | --- |
| Fig. 1 任务示意 | `fig1.png` |
| Fig. 2 构造与验证 | `fig2.png` |
| Fig. 3 组成 | `fig3a_families.pdf`, `fig3b_entanglement.pdf` |
| Fig. 4 功能结果 | `fig4.pdf` |
| Fig. 5 源码消融 | `fig5a_pass_rate.pdf`, `fig5b_paired_gain.pdf` |

`fig6.pdf` 与 `fig7.pdf` 仍在本目录，但压缩稿不再引用。旧文件名已归档。

## 目录

```text
figures/
  fig1.png … fig5b.pdf     ← 当前 main.tex / Overleaf 包引用的图
  scripts/                ← Fig. 3/4/5/7 源码；legacy/ 是历史设计
  data/                   ← 当前脚本用的派生 JSON/CSV
  output/                 ← 本地重画草稿，不进正文
```

预览请写到临时目录，不要覆盖正式 PDF：

```bash
python -B docs/paper/figures/scripts/redraw_figures.py --output-dir /tmp/flb-figures-preview
```

`python -B scripts/paper.py figures` 会覆盖 Fig. 3/4/5/7 的正式 PDF。Fig. 1/2/6 没有可精确重建的现有源码，不要用历史脚本冒充定稿。
