# 论文绘图源码索引

> **Status: current · Last verified: 2026-09-14**

| 图 | 独立源码 | 论文引用资产 | 状态 |
| --- | --- | --- | --- |
| Fig. 1 任务示意 | [legacy/fig1_motivation.py](legacy/fig1_motivation.py) | `../fig1.png` | 历史设计代码；当前 PNG 无精确 renderer |
| Fig. 2 构建验证 | [legacy/fig2_construction.py](legacy/fig2_construction.py) | `../fig2.png` | 历史设计代码；不是当前定稿源代码 |
| Fig. 3 任务组成 | [fig3_composition.py](fig3_composition.py) | `../fig3a_families.pdf`、`../fig3b_entanglement.pdf` | 一个源码文件输出两个面板 |
| Fig. 4 功能结果 | [fig4_functional_results.py](fig4_functional_results.py) | `../fig4.pdf` | 首败阶段单面板 |
| Fig. 5 源码消融 | [fig5_source_ablation.py](fig5_source_ablation.py) | `../fig5a_pass_rate.pdf`、`../fig5b_paired_gain.pdf` | 一个源码文件输出两个面板 |
| 附录 Fig. 6 分类交叉 | 无独立旧 renderer | `../fig6.pdf` | 压缩稿未引用；文件保留 |
| 附录 Fig. 7 配对产物 | [fig7_paired_footprint.py](fig7_paired_footprint.py) | `../fig7.pdf` | 压缩稿未引用；源码可运行 |

## 预览与正式覆盖

从项目根目录：

```bash
python -B docs/paper/figures/scripts/fig3_composition.py --output-dir /tmp/flb-fig3-preview
python -B docs/paper/figures/scripts/redraw_figures.py --output-dir /tmp/flb-all-preview
```

指定 `--output-dir` 时只写该目录，不改正式九图。省略该参数时，PDF/PNG 写到 `figures/output/`，并把同名 PDF 同步到 `figures/` 根目录（会覆盖正式资产）。批量入口只调度 Fig. 3/4/5/7，不覆盖 Fig. 1/2/6。

旧文件名与设计过程见 [`archive/paper_workspace_20260914/`](../../../../../archive/paper_workspace_20260914/README.md)。历史 Python 仍在 [legacy](legacy/README.md)。

## 共享代码

| 文件 | 职责 |
| --- | --- |
| [redraw_data.py](redraw_data.py) | 派生数据、计数、配对、bootstrap 核对 |
| [figure_data.py](figure_data.py) | 结果读取、校验、Matplotlib 初始化 |
| [paper_style.py](paper_style.py) | 字体、色彩、画布导出 |
| [figure_common.py](figure_common.py) | 单图命令行、预览隔离、正式 PDF 同步 |
| [redraw_figures.py](redraw_figures.py) | 批量调度；布局在各图源码内 |
