# 当前论文画图代码（2026-09-29）

一张图片对应一个 Python 文件；每个文件独立运行，不依赖项目目录中的数据文件。

安装依赖：

    python -m pip install -r requirements.txt

例如生成 Fig. 4(a)：

    python fig04a_ablation_pass_rate.py --output-dir output

其他脚本同样使用 `--output-dir output`。输出图片放在 `output/`，请先检查再替换论文正式图片。

本包对应当前正文的 Fig. 3(a,b)、Fig. 4(a,b,c)、Fig. 5、Fig. 6、Fig. 7(a,b)、Fig. 8(a,b)。其中 Fig. 4(a–c) 使用当前正文的 40 题结果；未纳入 150 题 RQ2 草稿。Fig. 1 和 Fig. 2 没有独立 Python 绘图脚本。

注意：Fig. 6 是手工编辑的定稿 PNG；`fig06_qualitative_cases.py` 仅导出内嵌的图片，不能逐元素编辑。

脚本中使用的是冻结的绘图数值。若要改变实验数值，应回到项目中的数据与可复算绘图流程核对，而非只修改图中的常量。
